package pb;


public class test_p8 {
	public static void main(String[] args )
	{
		pa.Car car1;
		car1 = new pa.Car();
		car1.show();
				
	}

}
