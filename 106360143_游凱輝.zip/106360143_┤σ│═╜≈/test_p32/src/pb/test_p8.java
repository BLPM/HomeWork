package pb;


public class test_p8 {
	public static void main (String[] args )throws CarException
	{
		Car car1;
		car1 = new Car();
		car1.setCar(1234, -10);



		System.out.println("���\");
	}

}
