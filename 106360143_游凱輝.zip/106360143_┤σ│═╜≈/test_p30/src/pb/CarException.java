package pb;

public class CarException extends Exception {

}
